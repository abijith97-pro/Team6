package com.example.demo;

import com.example.demo.Data.DongleRepo;
import com.example.demo.Data.PostRepo;
import com.example.demo.Data.PrepaidPlanRepo;
import com.example.demo.Model.Dongle;
import com.example.demo.Model.PostPaid;
import com.example.demo.Model.PrepaidPlan;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@EnableMongoRepositories("com.example.demo.Data")
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
    @Bean
    public CommandLineRunner dataLoader(DongleRepo repo, PostRepo repo1, PrepaidPlanRepo repo2) {
        repo.deleteAll();
        repo1.deleteAll();
        repo2.deleteAll();
        return args -> {
            repo.save(new Dongle("Voizfoni","180 days","Rs. 190"));
            repo.save(new Dongle("Logitechi","30 days","Rs. 299"));
            repo.save(new Dongle("Vifi","365 days","Rs. 567"));
            repo.save(new Dongle("Premium","365 days","Rs. 507"));
            repo.save(new Dongle("Omni","180 days","Rs. 200"));
            repo.save(new Dongle("5Gs","300 days","Rs. 799"));
            repo1.save(new PostPaid("Dhamaka-Deal","100 days","Rs. 190"));
            repo1.save(new PostPaid("Unlimited-Talks","30 days","Rs.299"));
            repo1.save(new PostPaid("Datafi","45 days","Rs. 567"));
            repo1.save(new PostPaid("Locals","50 days","Rs. 150"));
            repo1.save(new PostPaid("Get-Ready","30 days","Rs. 299"));
            repo1.save(new PostPaid("Myfam","45 days","Rs. 157"));
            repo2.save(new PrepaidPlan("Voizi","28 days","Rs. 190"));
            repo2.save(new PrepaidPlan("Preplan","360 days","Rs. 699"));
            repo2.save(new PrepaidPlan("Freedom","5 days","Rs. 100"));
            repo2.save(new PrepaidPlan("Weekend-deal","28 days","Rs. 190"));
            repo2.save(new PrepaidPlan("August-offer","30 days","Rs. 99"));
            repo2.save(new PrepaidPlan("Data-g","1 day","Rs. 100"));


        };
    }

}
